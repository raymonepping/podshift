# podshift

Automation scripts and utilities for shell-based workflows.

> This project was scaffolded automatically using `generate_project.sh`.

## License

[GPLv3](LICENSE)
